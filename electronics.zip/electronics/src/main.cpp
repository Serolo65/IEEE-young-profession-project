 
#include <Wire.h> 
#include <Adafruit_GFX.h> 
#include <Adafruit_SSD1306.h> 
#include <DHT.h> 
 
// --- Pin definitions --- 
// On microcontrollers, pins are just numbers referring to physical legs on the chip. 
// We use #define (a compile-time text substitution) instead of variables so these 
// pin numbers cost zero RAM and can't accidentally change at runtime. 
// Pin configuaration : 
#define CRITICAL_LED 6 
#define WARNING_LED 5 
#define NO_THREAT_LED 4 
#define m_RGB_BUILTIN 38 // OR 48 OR 38 
#define m_BUZZER 7 
#define m_TRIG_PIN 17 // Pin IO1 
#define m_ECHO_PIN 18 // Pin IO2 
#define m_Wind_Speed 1 
 
#define test_sig 8 
 
#define DHTPIN 9 
#define DHTTYPE DHT22 // We will be using DHT22 for simulations only. For the protoype we'll be using the 
//DHT11 
DHT dht(DHTPIN, DHTTYPE); //Creates a DHT sensor object bound to DHTPIN, so all future dht.readX() calls 
//know which physical pin to talk to. 
 
//Initialize thresholds parameters : 
 
const float Critical_Hum = 90.0f;  //in %
const float Warning_Hum = 60.0f;   //in %
const float Critical_Temp = 5.0f;   //in degrees Celsius
const float Warning_Temp = 15.0f; //
const float Critical_wind = 60.0f;  //in km/h
const float Warning_Wind = 30.0f; 
const float Critical_WL = 80.0f;  //in cm
const float Warning_WL = 50.0f;  
 
// OLED Configuration (I2C 4 pin) 
#define SCREEN_WIDTH 128 
#define SCREEN_HEIGHT 64 
#define OLED_RESET    -1 // -1 tells the library "this display shares the board's reset line", 
#define SCREEN_ADDRESS 0x3C // The I2C "address" of the OLED — I2C is a bus where many devices share the 
//same two wires (SDA/SCL), and each device is picked out by a unique address, much like a house number on 
//a street. 
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET); 
 
/* 
//Define custom SPI pins for ESP32-S3 (7 pin) 
#define OLED_CS     10 // CS 
#define OLED_DC     11 // DC 
#define OLED_RESET  12 // RES 
#define OLED_MOSI   13 // D1 
#define OLED_CLK    14 // D0 
 
// Initialize the display using Software SPI constructor 
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, OLED_MOSI, OLED_CLK, OLED_DC, OLED_RESET, OLED_CS); 
*/ 
 
void setup()  
{ 
  // put your setup code here, to run once: 
  // setup() runs exactly once when the board powers on or resets. This is where we 
  // configure hardware (pin directions, communication buses) before the main loop starts. 
  Serial.begin(115200); // Opens a serial (UART) connection to the computer at 115200 bits/sec : both 
//sides must agree on this "baud rate" or the text will be garbled. 
  Serial.println("Hello, ESP32-S3!"); 
 
  // pinMode tells the microcontroller whether a pin should behave as an output (we drive voltage out, 
//e.g. to light an LED) or an input (we read voltage in, e.g. from a sensor or button). 
  pinMode(CRITICAL_LED, OUTPUT); 
  pinMode(WARNING_LED, OUTPUT); 
  pinMode(NO_THREAT_LED, OUTPUT); 
  //pinMode(RGB_BUILTIN, OUTPUT); 
  pinMode(test_sig,OUTPUT); 
  //pinMode(m_BUZZER,OUTPUT); 
  //pinMode(m_Wind_Speed,OUTPUT); 
  pinMode(m_TRIG_PIN, OUTPUT); //Ultrasonic sensor: we OUTPUT a short pulse on TRIG to "ask" it to 
//measure. 
  pinMode(m_ECHO_PIN, INPUT);  // then INPUT lets us listen for its reply pulse on ECHO. 
 
  neopixelWrite(m_RGB_BUILTIN,50,255,100); // Sets the onboard RGB LED's color using raw (Red, Green, 
//Blue) values from 0-255 each. 
  digitalWrite(test_sig,HIGH); // Sets a pin's output voltage directly: HIGH ≈ full voltage (e.g. 3.3V), 
//LOW ≈ 0V. 
 
  // Configure ESP32-S3 hardware ADC resolution to 12-bit (0-4095 range) 
  analogReadResolution(12); 
 
  // Custom I2C pin assignment for ESP32-S3 DevKit 
  // Here we explicitly tell the ESP32 to use pin 11 for data and pin 12 for clock before any I2C device 
//(like the OLED) is used. 
  Wire.begin(11, 12); // SDA=Pin 11, SCL=Pin 12 
 
  // display.begin() initializes the OLED over I2C and returns false if the display 
  // isn't found/responding (e.g. wrong address or bad wiring). We deliberately halt 
  // execution here (an infinite empty for-loop) rather than continue with a broken 
  // display, since later display calls would silently fail or crash. 
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) { 
    Serial.println(F("OLED initialization failed!")); 
    for(;;); // Infinite loop = intentional "halt". Embedded systems have no OS to 
             // fall back to, so this is how we safely stop everything. 
  } 
   
  dht.begin(); 
  display.clearDisplay(); // Clears the OLED's internal frame buffer (not yet shown on screen). 
  display.setTextColor(SSD1306_WHITE); 
  display.setTextSize(1); 
  display.setCursor(10, 20); // Sets where the next text will be drawn, in (x, y) pixel coordinates — 
//(0,0) is the top-left corner of the screen. 
  display.print("System Booting..."); 
  display.display();  // IMPORTANT: drawing commands only change an in-memory buffer; 
                      // nothing appears on the physical screen until display() is called 
                      // to push that buffer over I2C to the OLED hardware. 
  delay(1500); // Pauses the whole program for 1500 ms. This is a BLOCKING delay — no other 
               // code (sensor reads, button checks, etc.) can run while it waits. Fine here 
               // during one-time setup, but risky if overused inside loop(). 
   
} 
 
void loop()  
{ 
  // put your main code here, to run repeatedly: 
  // loop() runs over and over, forever, after setup() finishes — this is the heartbeat 
  // of an embedded program (there is no "end" to reach, unlike a typical desktop script). 
 
  float m_temp = dht.readTemperature(); 
  float m_hum = dht.readHumidity(); 
  // Note: DHT sensors can occasionally fail to respond, in which case 
  // these functions return NaN ("Not a Number"). Production code should check for 
  // isnan(m_temp) before trusting the value, though it's omitted here for simplicity. 
 
  // Read wind speed and convert raw analog (0-4095) to wind speed (0-120 km/h) 
  int rawWind = analogRead(m_Wind_Speed); // Returns a raw integer 0-4095 (see analogReadResolution above) 
  float windSpeed = (rawWind / 4095.0) * 120.0; // Linear scaling: map the raw ADC range (0-4095) 
                                                // onto our assumed real-world sensor range (0-120 km/h). 
                                                // This assumes the sensor's output is linear across that 
//range. 
 
  // Read Ultrasonic Sensor for Water Level calculation 
  // Ultrasonic distance sensors work by timing how long a sound pulse takes to 
  // bounce off a surface and return, similar to how bats or submarine sonar work. 
  digitalWrite(m_TRIG_PIN, LOW); 
  delayMicroseconds(10);// Brief pause measured in MICROseconds (millionths of a second) — 
                         // needed because the sensor's datasheet specifies precise timing 
                         // for the trigger pulse to be recognized correctly. 
  digitalWrite(m_TRIG_PIN, HIGH);// Send a 10-microsecond "trigger" pulse; this tells the sensor "emit an 
//ultrasonic pulse now." 
  delayMicroseconds(10); 
  digitalWrite(m_TRIG_PIN, LOW); 
 
  long duration = pulseIn(m_ECHO_PIN, HIGH); // Blocks and measures (in microseconds) how long 
                                             // the ECHO pin stays HIGH — i.e. the round-trip 
                                             // travel time of the sound pulse. 
  float measuredDistanceCm = duration * 0.0343 / 2.0; // 0.0343 cm/microsecond is approximately the speed 
//of sound in air. We multiply by 
  // duration to get total distance traveled (there AND back), then divide by 2 to get 
  // the one-way distance to the water surface. 
 
   
 
  Serial.println("========================================="); 
  Serial.println("Initializing Weather & Tank Station..."); 
  Serial.println("========================================="); 
  Serial.println("\n--- NEW TELEMETRY REPORT ---"); 
  Serial.print("Temperature : "); Serial.print(m_temp, 1);       Serial.println(" C"); 
  Serial.print("Humidity    : "); Serial.print(m_hum, 1);        Serial.println(" %"); 
   
  // These conditions use AND (&&), meaning ALL FOUR readings must simultaneously 
  // cross their threshold for a Warning/Critical state to trigger — a single bad 
  // reading (e.g. just high humidity) will NOT be enough on its own. Depending on 
  // the real-world scenario this models, students should consider whether OR (||) 
  // logic might be safer (e.g. triggering Critical if ANY one measurement is severe). 
  bool is_Warning = ((m_hum > Warning_Hum ) && (m_temp < Warning_Temp ) && (windSpeed > Warning_Wind) && 
(measuredDistanceCm > Warning_WL)); 
  bool is_Critical = ((m_hum > Critical_Hum) && (m_temp < Critical_Temp) && (windSpeed > Critical_wind) && 
(measuredDistanceCm > Critical_WL)); 
 
  if (is_Critical) 
  { 
    digitalWrite(CRITICAL_LED,HIGH); 
    digitalWrite(WARNING_LED,LOW); 
    digitalWrite(NO_THREAT_LED,LOW); 
    tone(m_BUZZER, 5000); //Generates a continuous 5000 Hz square wave on the buzzer pin, 
  } 
  else if (is_Warning) 
  { 
    digitalWrite(CRITICAL_LED,LOW); 
    digitalWrite(WARNING_LED,HIGH); 
    digitalWrite(NO_THREAT_LED,LOW); 
    tone(m_BUZZER, 3000); 
  } 
  else 
  { 
    digitalWrite(CRITICAL_LED,LOW); 
    digitalWrite(WARNING_LED,LOW); 
    digitalWrite(NO_THREAT_LED,HIGH); 
    noTone(m_BUZZER); // Stops any tone currently playing on the buzzer. 
  } 
 
  display.clearDisplay(); 
  display.setTextSize(1); 
  display.setCursor(0, 0); 
  display.print("- TELEMETRY MONITOR -"); 
 
  display.setCursor(0, 14); 
  display.print("Temp: "); display.print(m_temp, 1); display.print(" C"); 
 
  display.setCursor(0, 24); 
  display.print("Humi: "); display.print(m_hum, 1); display.print(" %"); 
 
  display.setCursor(0, 34); 
  display.print("Wind: "); display.print(windSpeed, 1); display.print(" km/h"); 
 
  display.setCursor(0, 44); 
  display.print("Water: "); display.print(measuredDistanceCm, 1); display.print(" cm"); 
 
  display.display(); // Push the completed frame buffer to the physical screen in one go — 
                     // batching all draw calls before one display() call avoids flicker. 
   
  delay(5000); // Blocking delay: the entire loop() pauses for 5 seconds before repeating. 
              // Nothing else (buttons, other sensors, faster blinking, etc.) can happen 
              // during this time. For more advanced projects, students should look into 
              // millis()-based non-blocking timing to avoid this limitation. 
} 
